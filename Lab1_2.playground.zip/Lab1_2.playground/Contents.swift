import Foundation

func combineStrings() {
    print("Enter the first line:")
    guard let line1 = readLine() else {
        print("Invalid input for the first line.")
        return
    }

    print("Enter the second line:")
    guard let line2 = readLine() else {
        print("Invalid input for the second line.")
        return
    }

    let combinedString = line1 + " " + line2
    print("Combined String: \(combinedString)")
}

func flipString() {
    print("Enter a string:")
    guard let inputString = readLine() else {
        print("Invalid input.")
        return
    }

    let flippedString = String(inputString.reversed())
    print("Flipped String: \(flippedString)")
}

func countCharacters() {
    print("Enter a string:")
    guard let inputString = readLine() else {
        print("Invalid input.")
        return
    }

    let characterCount = inputString.filter { !$0.isWhitespace }.count
    print("Character Count (excluding spaces): \(characterCount)")
}

func searchSubstring() {
    print("Enter the string:")
    guard let inputString = readLine() else {
        print("Invalid input.")
        return
    }

    print("Enter the substring to search for:")
    guard let substring = readLine() else {
        print("Invalid input for the substring.")
        return
    }

    if let range = inputString.range(of: substring) {
        let index = inputString.distance(from: inputString.startIndex, to: range.lowerBound)
        print("Substring found at index: \(index)")
    } else {
        print("Substring not found.")
    }
}

// Main Program
combineStrings()
flipString()
countCharacters()
searchSubstring()
